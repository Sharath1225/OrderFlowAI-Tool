// ─────────────────────────────────────────────
//  OrderFlow AI — app.js
//  NLP Order Management System
// ─────────────────────────────────────────────

// ── State ──────────────────────────────────────
let orders = JSON.parse(localStorage.getItem('of_orders') || '[]');
let nextId  = parseInt(localStorage.getItem('of_nextId') || '1');

// ── Helpers ────────────────────────────────────
function save() {
  localStorage.setItem('of_orders', JSON.stringify(orders));
  localStorage.setItem('of_nextId', String(nextId));
  updateStats();
  renderStrip();
}

function now() {
  return new Date().toLocaleString('en-IN', {
    day:'2-digit', month:'short', year:'numeric',
    hour:'2-digit', minute:'2-digit'
  });
}

function getStatusIndex(status) {
  return ['Received','In Review','Accepted'].indexOf(status);
}

function badgeClass(status) {
  if (status === 'Received')  return 'badge-received';
  if (status === 'In Review') return 'badge-review';
  if (status === 'Accepted')  return 'badge-accepted';
  return '';
}

// ── NLP Parser ─────────────────────────────────
function parse(text) {
  const t = text.trim();
  const tl = t.toLowerCase();

  // ── 1. Quality update ──
  const qualRe = /quality\s+(?:update|check|report|note)\s+(?:on|for)?\s*order\s*#?(\d+)[—\-–:,]?\s*(.*)/i;
  const qualM  = t.match(qualRe);
  if (qualM) return { intent:'quality', id:parseInt(qualM[1]), note: qualM[2].trim() || 'Quality checkpoint logged.' };

  // ── 2. Status update ──
  // "mark order #N as X" | "order #N has been X" | "set order #N to X" | "order #N is now X"
  const statusRe = /(?:mark|set|update|move)?\s*order\s*#?(\d+)\s*(?:as|to|has been|is now|→|->)?\s*(received|in\s*review|accepted)/i;
  const statusM  = t.match(statusRe);
  if (statusM) {
    let s = statusM[2].trim().toLowerCase();
    if (s === 'in review' || s === 'inreview') s = 'In Review';
    else s = s.charAt(0).toUpperCase() + s.slice(1);
    return { intent:'status', id: parseInt(statusM[1]), status: s };
  }

  // Also catch "order #N has been reviewed" → In Review, "accepted" → Accepted
  const statusRe2 = /order\s*#?(\d+)\s+(?:has been|is|was)\s+(reviewed|accepted|received)/i;
  const statusM2  = t.match(statusRe2);
  if (statusM2) {
    let w = statusM2[2].toLowerCase();
    let s = w === 'reviewed' ? 'In Review' : w.charAt(0).toUpperCase() + w.slice(1);
    return { intent:'status', id: parseInt(statusM2[1]), status: s };
  }

  // ── 3. Status check ──
  const checkRe = /(?:status|check|where is|track)\s+(?:of\s+)?order\s*#?(\d+)/i;
  const checkM  = t.match(checkRe);
  if (checkM) return { intent:'check', id: parseInt(checkM[1]) };

  // ── 4. List all ──
  if (/(?:list|show|view|display|all)\s+(?:all\s+)?orders?/i.test(tl) ||
      /what(?:'s| are) (?:my|the|all) orders?/i.test(tl)) {
    return { intent:'list' };
  }

  // ── 5. New Order ──
  // Look for a quantity + material/part combo + optional deadline
  const qtyRe   = /(\d[\d,]*)\s*(pcs?|pieces?|units?|nos?\.?|numbers?|sets?)?/i;
  const deadRe  = /(?:by|before|due|deliver(?:ed|y)?\s*(?:by)?|deadline[:\s]*)([A-Za-z]+\s+\d{1,2}(?:st|nd|rd|th)?(?:,?\s*\d{4})?|\d{1,2}[\/\-]\d{1,2}(?:[\/\-]\d{2,4})?)/i;

  const qtyM = t.match(qtyRe);
  const deadM = t.match(deadRe);

  if (qtyM) {
    const qty = parseInt(qtyM[1].replace(/,/g,''));
    const deadline = deadM ? deadM[1].trim() : 'Not specified';

    // Extract part name — strip quantity, deadline phrases, noise words
    let part = t
      .replace(qtyM[0], '')
      .replace(deadM ? deadM[0] : '', '')
      .replace(/\b(i need|we need|please|order|can you|could you|make|create|produce|manufacture|get me|send me)\b/gi, '')
      .replace(/\b(of|the|some|a|an)\b/gi, '')
      .replace(/[,\.\!\?]+/g, '')
      .replace(/\s{2,}/g, ' ')
      .trim();

    // Try to extract material and part separately
    const materialRe = /(titanium|steel|aluminium|aluminum|copper|brass|iron|carbon\s*fiber|plastic|stainless|nylon|zinc|nickel|tungsten|chrome|gold|silver|bronze)\s*/i;
    const matM = part.match(materialRe);
    let material = matM ? matM[1].trim() : '';
    if (material) part = part.replace(materialRe, '').trim();

    const partName = material
      ? `${capitalize(material)} ${capitalize(part)}`
      : capitalize(part || 'Custom Part');

    // Extract spec (e.g. 80mm bore, M12, grade 5, etc.)
    const specRe = /\b(\d+\s*mm\b[\s\w]*|\bM\d+\b|\bgrade\s*\d+\b|\b\d+[xX]\d+\b)/i;
    const specM  = t.match(specRe);
    const spec   = specM ? specM[1].trim() : '';

    return { intent:'new_order', partName, material: capitalize(material)||'—', qty, deadline, spec };
  }

  // Fallback: help / greeting
  if (/^(hi|hello|hey|help|what can you do)[\s!?.]*$/i.test(tl)) {
    return { intent:'greet' };
  }

  return { intent:'unknown' };
}

function capitalize(s) {
  if (!s) return '';
  return s.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

// ── Order Manager ───────────────────────────────
function createOrder({ partName, material, qty, deadline, spec }) {
  const order = {
    id: nextId++,
    partName, material, qty, deadline, spec,
    status: 'Received',
    createdAt: now(),
    updatedAt: now(),
    qualityLogs: []
  };
  orders.push(order);
  save();
  return order;
}

function getOrder(id) {
  return orders.find(o => o.id === id);
}

function updateStatus(id, status) {
  const o = getOrder(id);
  if (!o) return null;
  o.status = status;
  o.updatedAt = now();
  save();
  return o;
}

function addQualityLog(id, note) {
  const o = getOrder(id);
  if (!o) return null;
  o.qualityLogs.push({ ts: now(), note });
  o.updatedAt = now();
  save();
  return o;
}

// ── UI Helpers ──────────────────────────────────
function updateStats() {
  document.getElementById('stat-total').textContent    = orders.length;
  document.getElementById('stat-accepted').textContent = orders.filter(o=>o.status==='Accepted').length;
  document.getElementById('stat-review').textContent   = orders.filter(o=>o.status==='In Review').length;
}

function renderStrip() {
  const strip = document.getElementById('order-cards-strip');
  strip.innerHTML = '';
  orders.slice().reverse().slice(0,6).reverse().forEach(o => {
    const c = document.createElement('div');
    c.className = 'strip-card';
    c.title = `${o.partName} — ${o.status}`;
    c.innerHTML = `<span class="strip-card-id">#${o.id}</span><span class="strip-card-part">${o.partName.slice(0,20)}</span>`;
    c.onclick = () => {
      switchView('dashboard');
    };
    strip.appendChild(c);
  });
}

// ── Chat Renderer ───────────────────────────────
function appendMsg(role, html) {
  const body  = document.getElementById('chat-body');
  const div   = document.createElement('div');
  div.className = `msg ${role}`;
  const avatar = role === 'bot' ? '🤖' : '👤';
  div.innerHTML = `
    <div class="msg-avatar">${avatar}</div>
    <div class="msg-bubble">${html}<div class="msg-time">${now()}</div></div>
  `;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
}

function showTyping() {
  const body = document.getElementById('chat-body');
  const div  = document.createElement('div');
  div.id = 'typing';
  div.className = 'msg bot';
  div.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="msg-bubble" style="padding:10px 16px">
      <div class="typing-indicator"><span></span><span></span><span></span></div>
    </div>
  `;
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
  return div;
}

function removeTyping() {
  const t = document.getElementById('typing');
  if (t) t.remove();
}

function orderCardHTML(o) {
  return `
    <div class="order-card-msg">
      <div class="oc-header">
        <span class="oc-id">Order #${o.id}</span>
        <span class="badge ${badgeClass(o.status)}">${o.status}</span>
      </div>
      <div class="oc-rows">
        <div class="oc-row"><span class="oc-key">Part</span><span class="oc-val">${o.partName}</span></div>
        <div class="oc-row"><span class="oc-key">Qty</span><span class="oc-val">${o.qty.toLocaleString()}</span></div>
        <div class="oc-row"><span class="oc-key">Deadline</span><span class="oc-val">${o.deadline}</span></div>
        ${o.material && o.material !== '—' ? `<div class="oc-row"><span class="oc-key">Material</span><span class="oc-val">${o.material}</span></div>` : ''}
        ${o.spec ? `<div class="oc-row"><span class="oc-key">Spec</span><span class="oc-val">${o.spec}</span></div>` : ''}
      </div>
    </div>`;
}

function qualityHTML(log) {
  return `
    <div class="quality-msg">
      <div class="q-time">📅 ${log.ts}</div>
      <div class="q-note">✅ ${log.note}</div>
    </div>`;
}

// ── Process Message ─────────────────────────────
function processIntent(parsed) {
  switch (parsed.intent) {

    case 'new_order': {
      const o = createOrder(parsed);
      renderDashboard();
      return `
        <p>✅ <strong>Order created successfully!</strong></p>
        ${orderCardHTML(o)}
        <p style="margin-top:10px;font-size:13px;color:#94a3b8">You can update the status anytime — e.g. <em>"Mark order #${o.id} as in review"</em></p>
      `;
    }

    case 'status': {
      const o = getOrder(parsed.id);
      if (!o) return `<p>❌ Order <strong>#${parsed.id}</strong> not found. Please check the order number.</p>`;
      const prev = o.status;
      const updated = updateStatus(parsed.id, parsed.status);
      renderDashboard();
      return `
        <p>🔄 <strong>Status updated!</strong></p>
        ${orderCardHTML(updated)}
        <p style="margin-top:10px;font-size:13px;color:#94a3b8">${prev} → <strong>${parsed.status}</strong></p>
      `;
    }

    case 'quality': {
      const o = getOrder(parsed.id);
      if (!o) return `<p>❌ Order <strong>#${parsed.id}</strong> not found.</p>`;
      if (o.status === 'Received') return `<p>⚠️ Order <strong>#${parsed.id}</strong> is still in <em>Received</em> status. Quality logs are typically added after the order is <strong>Accepted</strong>. Log anyway? Just confirm.</p>`;
      const log = { ts: now(), note: parsed.note };
      addQualityLog(parsed.id, parsed.note);
      renderDashboard();
      return `
        <p>📋 <strong>Quality log added to Order #${parsed.id}</strong></p>
        ${qualityHTML(log)}
      `;
    }

    case 'check': {
      const o = getOrder(parsed.id);
      if (!o) return `<p>❌ Order <strong>#${parsed.id}</strong> not found.</p>`;
      const latestQ = o.qualityLogs.length ? o.qualityLogs[o.qualityLogs.length-1] : null;
      return `
        <p>📦 <strong>Order #${o.id} Status</strong></p>
        ${orderCardHTML(o)}
        ${latestQ ? `<p style="margin-top:8px;font-size:12px;color:#94a3b8">Latest quality note:</p>${qualityHTML(latestQ)}` : '<p style="margin-top:8px;font-size:12px;color:#6b7280">No quality logs yet.</p>'}
      `;
    }

    case 'list': {
      if (!orders.length) return `<p>📭 No orders placed yet. Try: <em>"I need 100 steel bolts by August 10"</em></p>`;
      const rows = orders.map(o =>
        `<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(255,255,255,0.05)">
          <span style="font-size:13px;color:#3b82f6;font-weight:600">#${o.id}</span>
          <span style="font-size:13px;flex:1;margin:0 10px">${o.partName}</span>
          <span class="badge ${badgeClass(o.status)}">${o.status}</span>
        </div>`
      ).join('');
      return `<p>📋 <strong>All Orders (${orders.length})</strong></p>${rows}`;
    }

    case 'greet':
      return `<p>👋 Hello! I'm <strong>OrderFlow AI</strong>. I can help you:</p>
        <ul>
          <li>📦 Place a new order — describe what you need</li>
          <li>🔄 Update status — "Mark order #1 as accepted"</li>
          <li>📋 Log quality — "Quality update on order #1 — passed inspection"</li>
          <li>🔍 Check status — "Status of order #1"</li>
          <li>📊 List all — "Show all orders"</li>
        </ul>`;

    default:
      return `<p>🤔 I didn't quite understand that. Here are some things I can do:</p>
        <ul>
          <li><em>"I need 200 titanium flanges, 80mm bore, by July 20"</em></li>
          <li><em>"Mark order #1 as accepted"</em></li>
          <li><em>"Quality update on order #1 — passed visual inspection"</em></li>
          <li><em>"Status of order #1"</em> or <em>"Show all orders"</em></li>
        </ul>`;
  }
}

// ── Send Message ────────────────────────────────
function sendMessage() {
  const input = document.getElementById('chat-input');
  const text  = input.value.trim();
  if (!text) return;

  // User bubble
  appendMsg('user', `<p>${escapeHtml(text)}</p>`);
  input.value = '';
  autoResize(input);

  // Typing indicator
  const typing = showTyping();

  setTimeout(() => {
    removeTyping();
    const parsed   = parse(text);
    const response = processIntent(parsed);
    appendMsg('bot', response);
  }, 600 + Math.random() * 400);
}

function escapeHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
  autoResize(e.target);
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

function clearChat() {
  const body = document.getElementById('chat-body');
  body.innerHTML = '';
  appendMsg('bot', `<p>Chat cleared! I'm still here — how can I help you? 😊</p>`);
}

// ── View Switcher ───────────────────────────────
function switchView(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.getElementById(`view-${view}`).classList.add('active');
  document.getElementById(`nav-${view}`).classList.add('active');
  if (view === 'dashboard') renderDashboard();
}

// ── Dashboard Renderer ──────────────────────────
function renderDashboard() {
  const grid   = document.getElementById('orders-grid');
  const filter = document.getElementById('filter-status').value;
  const list   = filter ? orders.filter(o=>o.status===filter) : orders;

  if (!list.length) {
    grid.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📭</div>
        <div class="empty-title">${filter ? 'No orders with status: ' + filter : 'No orders yet'}</div>
        <div class="empty-sub">Go to the chat and place your first order!</div>
      </div>`;
    return;
  }

  grid.innerHTML = list.slice().reverse().map(o => {
    const statuses = ['Received','In Review','Accepted'];
    const idx = getStatusIndex(o.status);

    const trackSteps = statuses.map((s, i) => {
      let cls = '';
      if (i < idx) cls = 'done';
      else if (i === idx) cls = 'done active';
      return `<div class="track-step ${cls}"><div class="track-dot"></div><div class="track-label">${s}</div></div>`;
    }).join('');

    const qlogs = o.qualityLogs.length
      ? o.qualityLogs.slice().reverse().slice(0,3).map(q =>
          `<div class="q-log-item"><div class="q-ts">${q.ts}</div>${escapeHtml(q.note)}</div>`
        ).join('')
      : `<div class="no-quality">No quality logs yet</div>`;

    return `
      <div class="dash-card">
        <div class="dash-card-header">
          <div class="dash-card-id">Order #${o.id}</div>
          <span class="badge ${badgeClass(o.status)}">${o.status}</span>
        </div>
        <div class="dash-card-body">
          <div><div class="dash-field-key">Part Name</div><div class="dash-field-val">${o.partName}</div></div>
          <div><div class="dash-field-key">Quantity</div><div class="dash-field-val">${o.qty.toLocaleString()}</div></div>
          <div><div class="dash-field-key">Deadline</div><div class="dash-field-val">${o.deadline}</div></div>
          <div><div class="dash-field-key">Material</div><div class="dash-field-val">${o.material||'—'}</div></div>
          ${o.spec ? `<div><div class="dash-field-key">Spec</div><div class="dash-field-val">${o.spec}</div></div>` : ''}
          <div><div class="dash-field-key">Created</div><div class="dash-field-val" style="font-size:11px;font-weight:400">${o.createdAt}</div></div>
        </div>
        <div class="status-track">${trackSteps}</div>
        <div class="quality-logs">
          <div class="quality-log-header">🔬 Quality Logs (${o.qualityLogs.length})</div>
          ${qlogs}
        </div>
      </div>`;
  }).join('');
}

// ── Init ────────────────────────────────────────
updateStats();
renderStrip();
renderDashboard();
