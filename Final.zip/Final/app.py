# app.py

from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# Secret Key
app.config['SECRET_KEY'] = 'secretkey123'

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# -----------------------------
# DATABASE MODEL
# -----------------------------

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fullname = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(250), nullable=False)

# -----------------------------
# HOME
# -----------------------------

@app.route('/')
def home():

    if 'user_id' in session:
        return redirect(url_for('login'))

    return redirect(url_for('login'))

# -----------------------------
# REGISTER
# -----------------------------

@app.route('/register', methods=['GET', 'POST'])
def register():

    if request.method == 'POST':

        fullname = request.form['fullname']
        email = request.form['email']
        password = request.form['password']
        confirm = request.form['confirm']

        # Validation

        if password != confirm:
            flash('Passwords do not match!', 'danger')
            return redirect(url_for('register'))

        existing_user = User.query.filter_by(email=email).first()

        if existing_user:
            flash('User already exists!', 'danger')
            return redirect(url_for('register'))

        # Hash Password

        hashed_password = generate_password_hash(password)

        # Save User

        new_user = User(
            fullname=fullname,
            email=email,
            password=hashed_password
        )

        db.session.add(new_user)
        db.session.commit()

        flash('Registration Successful!', 'success')

        return redirect(url_for('login'))

    return render_template('register.html')

# -----------------------------
# LOGIN
# -----------------------------

@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):

            session['user_id'] = user.id
            session['user_name'] = user.fullname

            flash('Login Successful!', 'success')

            return redirect(url_for('dashboard'))

        else:
            flash('Invalid Email or Password!', 'danger')

    return render_template('login.html')

# -----------------------------
# DASHBOARD
# -----------------------------

@app.route('/dashboard')
def dashboard():

    if 'user_id' not in session:
        return redirect(url_for('login'))

    return render_template(
        'dashboard.html',
        username=session['user_name']
    )

# -----------------------------
# LOGOUT
# -----------------------------

@app.route('/logout')
def logout():

    session.clear()

    flash('Logged Out Successfully!', 'success')

    return redirect(url_for('login'))

# -----------------------------
# MAIN
# -----------------------------

if __name__ == '__main__':

    with app.app_context():
        db.create_all()

    app.run(debug=True)